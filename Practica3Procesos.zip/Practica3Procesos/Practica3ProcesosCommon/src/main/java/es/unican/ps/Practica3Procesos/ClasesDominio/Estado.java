package es.unican.ps.Practica3Procesos.ClasesDominio;

public enum Estado {
	REALIZADO,
	EN_PROGRESO,
	ENTREGADO
}
